package com.cnlms.rottenandroid.ui.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Author: Can Elmas <can.elmas@pozitron.com>
 * Date: 12/19/12 2:32 PM
 */
public final class FragSearch extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        /**
         *
         *  TO BE IMPLEMENTED
         *
         *  This is where you should return a view for this fragment.
         *
         *  Tip : inflate the view using 'inflater' parameter and a predefined layout
         *
         *
         */

        return super.onCreateView(inflater, container, savedInstanceState);
    }
}
