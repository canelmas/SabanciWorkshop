package com.cnlms.rottenandroid.ui.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import com.cnlms.rottenandroid.network.BaseAsyncTask;
import com.cnlms.rottenandroid.network.TestRequest;

/**
 * Author: Can Elmas <can.elmas@pozitron.com>
 * Date: 12/19/12 2:31 PM
 */
public final class FragInTheaterMovies extends Fragment  {

    private BaseAsyncTask.RequestListener requestListener;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        /**
         *
         *  TO BE IMPLEMENTED
         *
         *  This is where you should return a view for this fragment.
         *
         *  Tip : inflate the view using 'inflater' parameter and a predefined layout
         *
         *
         */


        /**
         *  Following statements is for helping you make requests properly.
         *
         *  You can keep the requestListener part and replace the TestRequest part with your requests
         */


        /**
         *  First initialize a request listener.
         *
         *  You should pass it as the second parameter to your request classes.
         *
         *  It will interpret the result of your request.
         */
        requestListener = new BaseAsyncTask.RequestListener() {

            @Override
            public void onSuccess(BaseAsyncTask request) {

                /**
                 *  What my app should do when my request succeeds?
                 *
                 *  In your requests, you can access the data fetched over the network,
                 *  e.g : ((TestRequest)request).getData();
                 *
                 *  DON'T FORGET TO CAST TO YOUR OWN REQUEST!
                 */

                Toast.makeText(getActivity(), "Test Request Succeeded!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(BaseAsyncTask request) {

                /**
                 *  What my app should do when my request fails?
                 */
                Toast.makeText(getActivity(), "Test Request Failed!", Toast.LENGTH_SHORT).show();

            }

        };


        TestRequest request = new TestRequest(getActivity(), requestListener);

        request.execute();


        return super.onCreateView(inflater, container, savedInstanceState);
    }
}
