package com.cnlms.rottenandroid;

/* This stub is for using by IDE only. It is NOT the R class actually packed into APK */
public final class R {
}